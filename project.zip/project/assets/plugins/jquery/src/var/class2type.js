define( function() {
	"use strict";

	// [[Class]] -> type pairs
	return {};
} );
