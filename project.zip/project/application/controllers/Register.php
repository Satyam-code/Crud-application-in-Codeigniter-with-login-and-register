<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	function __construct(){
		parent::__construct();
		//parent:: __construct();
		$this->load->library('javascript');
		$this->load->model('Register_model');
		$this->load->library('form_validation');
		//$this->load->library('email');
		//$this->load->library('session');
        // $this->load->model('product_model');
    //    $this->load->model('Clocking_model');
	}


	// public function index()
	// {
	// 	$this->load->view('register_new.php');
	// }

	
public function login()
	{
		if(is_logged_in()) redirect(base_url('index.php/Leads'));
        	
		$data = [
			'title'	=> 'Log In'
		];

	//	$this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
		$this->form_validation->set_rules('email', 'Email', 'required|trim');   // for Direct login through referral id
		$this->form_validation->set_rules('password', 'Password', 'required'); 

		if($this->form_validation->run() == true) {

			if ($this->input->post()) {
				//prevent CSRF
				if ($this->input->post('submitBtn') != 'submitBtn') die('You are not authorized to do this action');

				$check_auth = $this->Register_model->authonication();

				if ($check_auth) {
					//redirect previously fail admin url
				//	if(redirect_auth_uri()) redirect(redirect_auth_uri());
					//redirect Dashboard
					redirect(base_url('Leads'));
				} else {
					redirect(base_url('Register/login'));
				}
			}
		}
		$this->load->view('login', $data);
	}

	public function register(){

     $this->load->view('register_new.php');
		if($this->input->post()){


			if($this->input->post('submit') != 'userRegistration') die('Error! sorry');

          
					
					  //$this->form_validation->set_rules('gst_no', 'Gst No', 'required|trim');
				
					  $this->form_validation->set_rules('first_name', 'First name', 'required|trim');
					  $this->form_validation->set_rules('last_name', 'Last name', 'required|trim');

					  $this->form_validation->set_rules('password', 'Password', 'required|trim');
					  $this->form_validation->set_rules('passconf', 'Confirm Password', 'required|trim');

					 // $this->form_validation->set_rules('gst_reg', 'Gst Registration Date', 'required|trim');
					  $this->form_validation->set_rules('email', 'E-mail', 'required|trim');
					 // $this->form_validation->set_rules('firm_name', 'Firm Name', 'required|trim');
				
					 // $this->form_validation->set_rules('firm_add', 'Firm Address', 'required|trim');
					  //$this->form_validation->set_rules('city', 'City name', 'required|trim');

					//  $this->form_validation->set_rules('state', 'State', 'required|trim');
					  //$this->form_validation->set_rules('pincode', 'Pincode', 'required|trim');
					  $this->form_validation->set_rules('mob_no', 'Contact No', 'required|trim');
				
					
					 

            if($this->form_validation->run() == true)
            {
                $insert = $this->Register_model->register();
                if($insert)
                {
                    $this->session->set_flashdata('successMsg', 'Members Details Created Successfully');
                    redirect(base_url('Thank_you'));
                }else{
                	 $this->session->set_flashdata('successMsg', 'Members Details Failed');
                    redirect(base_url('Register/login'));
                }
            }

		}

		//$this->load->view('register_new.php');
	}

	 public function Logout()
    {
        $this->session->sess_destroy();
        redirect('Register/login');
    }
    
	



} // last bracket
