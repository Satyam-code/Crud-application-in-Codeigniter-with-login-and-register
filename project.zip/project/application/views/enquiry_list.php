<!DOCTYPE html>
<html class="no-js"> <!--<![endif]-->
<head>
  
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Aviato E-Commerce Template">
  
  <meta name="author" content="Themefisher.com">

  <title>Aficionado Technologies | Best Training Institute in Bangalore</title>

   <!-- Mobile Specific Meta-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicon -->
  <!-- <link rel="shortcut icon" type="assets/image/x-icon" href="img/favicon.png" /> -->
  <link rel='shortcut icon' type="assets/image/x-icon" href='<?php echo base_url();?>assets/img/favicon.png'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- bootstrap.min css -->
   <link rel='stylesheet' href='<?php echo base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css'>
 <!--  <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css"> -->
  <!-- Ionic Icon Css -->
  <link rel='stylesheet' href='<?php echo base_url();?>assets/plugins/Ionicons/css/ionicons.min.css'>
  <!-- <link rel="stylesheet" href="plugins/Ionicons/css/ionicons.min.css"> -->
  <!-- animate.css -->
  <link rel='stylesheet' href='<?php echo base_url();?>assets/plugins/animate-css/animate.css'>
  <!-- <link rel="stylesheet" href="plugins/animate-css/animate.css"> -->
  <!-- Magnify Popup -->
  <link rel='stylesheet' href='<?php echo base_url();?>assets/plugins/magnific-popup/dist/magnific-popup.css'>
 <!--  <link rel="stylesheet" href="plugins/magnific-popup/dist/magnific-popup.css"> -->
  <!-- Owl Carousel CSS -->
  <link rel='stylesheet' href='<?php echo base_url();?>assets/plugins/slick-carousel/slick/slick.css'>
  <link rel='stylesheet' href='<?php echo base_url();?>assets/plugins/slick-carousel/slick/slick-theme.css'>
  <!-- <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css"> -->
   <link href="<?php echo base_url('assets/admin'); ?>/js/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
  <!-- Main Stylesheet -->
  <link rel='stylesheet' href='<?php echo base_url();?>assets/style.css'>
  <!-- <link rel="stylesheet" href="css/style.css"> -->

  
</head>
 <!-- <?php include ("header.php")?>  -->
<body>
<section>   
               
                    
                        <br>
                    
                       <center> <label style="font-size:20px">Lead Deatils List</label></center>
                       <br>
                            <div class="col-lg-12 text-right" >
                        <a href="<?php echo base_url('Lead/add_leads') ?>" class="btn btn-primary btn-sm" style=" box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .23), inset 1px 1px 0 0 hsla(0, 0%, 100%, .2);">
                            <i class="fa fa-plus"></i> Add Leads
                        </a>

                        <a href="<?php echo base_url('dashboard') ?>" class="btn btn-warning btn-sm" style=" box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .23), inset 1px 1px 0 0 hsla(0, 0%, 100%, .2);">
                            <i class="fa fa-undo"></i> Back
                        </a>
                    </div> 
                 <br>

               
               <!--   <div class="box-body table-responsive" style="overflow-x: scroll;">
                   <div class="row" style="margin:auto;">
                        <div class="col-md-2 text-center col-xs-2" style="display: none;">
                            <select class="form-control" id="limit" style="width:100% auto;" onchange="change_limit()">
                                <option value="10">10 Records</option>
                                <option value="20">20 Records</option>
                                <option value="50">50 Records</option>
                                <option value="100">100 Records</option>
                                <option value="200">200 Records</option>
                                <option value="500">500 Records</option>
                                <option value="">All Records</option>
                            </select>
                        </div>
                      
                     
                    </div></div>
 -->

                    <br>
                    
                    <table id="example" class="table table-bordered table-striped table-hover">
                       
                            <tr><th>Name</th>
                                <th>Mobile</th>
                                <th>E-Mail</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>Date</th>
                                <th>Edit</th>
                            </tr>

                        <?php foreach($posts as $r){?>

                        <tr>
                                  
                                    
                                         <th><?php echo $r->name; ?></th>
                                         <th><?php echo $r->mobile; ?></th>
                                          <th><?php echo $r->email; ?></th>
                                         <th><?php echo $r->address; ?></th>
                                         <th><?php echo $r->city; ?></th>
                                          <th><?php echo $r->created_at; ?></th>
                                          <th><a href="'.base_url('').'" class="btn btn-sm btn-warning" title="Edit"> <i class="fa fa-edit"></i> </a></th>
                                         <?php   } ?>
                                        
</tr>
                                    
                        

                    </table>
                    
                    <!-- <input type="hidden" id="page_no" value="1"> -->
                    <div class="row" id="page_div" style="margin:auto;"></div>
                    
             

</section><!-- /.content -->
<!-- <?php include("footer.php"); ?> -->
</body>