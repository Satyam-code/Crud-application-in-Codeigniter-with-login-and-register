<!DOCTYPE html>
<html lang="en">
<head>
  <title>Apka Painter</title>
  <style>
   
      body {
 background-color: #f1f1f1;
}

 tbody {
 background-color: white;
}


  </style>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-danger navbar-dark">
  <ul class="navbar-nav">
  <li class="nav-item">
      <a class="navbar-brand"  href="<?php echo site_url('leads'); ?>">Apka Painter</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo site_url('Register/register'); ?>">Register</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo site_url('Register/login'); ?>">Login</a>
    </li>
   
  </ul>
</nav>
<br>

