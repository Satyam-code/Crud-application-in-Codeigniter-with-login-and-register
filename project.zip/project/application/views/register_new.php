<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<head>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/style.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="assets/js/modernizer.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
  <?php include("templates/header2.php") ?>
    
    <body>
    	<?php echo form_open_multipart('', ['role' => 'form', 'class' => 'form-horizontal']); ?>

<div class="container">
    <div class="jumbotron" style="/*background-color: #00BFFF; */box-shadow:5px 5px 10px gray;">
    	 <div class="container text-center"  style="/*background-color: #00BFFF; */">
            <i class="fa fa-leaf"></i> <h2 style="color:black;">  Registration</h2></div><br><hr><br>
            <?php echo form_open('', ['class' => 'form-horizontal']); ?>

            <div class="panel-body" >   
	<div class="col-lg-12 well">
	<div class="row">

				<form>
					<div class="col-sm-12">
						<div class="row">
							<div class="col-sm-6 form-group <?php if(form_error('first_name')) echo 'has-error'; ?>">
								<label>First Name <span style="color:red">*</span></label>
								<input type="text" placeholder="Enter First Name Here.." name="first_name" id="first_name" class="form-control">
								<font color="red"><?php echo form_error('first_name') ?></font>
								
							</div>

							<div class="col-sm-6 form-group <?php if(form_error('last_name')) echo 'has-error'; ?>">
								<label>Last Name <span style="color:red">*</span></label>
								<input type="text" placeholder="Enter Last Name Here.."  name="last_name" id="last_name"  class="form-control">
								<font color="red"><?php echo form_error('last_name') ?></font>
							</div>
						</div>

						<div class="form-group <?php if(form_error('email')) echo 'has-error'; ?>">
						<label>Email Address <span style="color:red">*</span></label>
						<input type="text" placeholder="Enter Email Address Here.."  name="email" id="email"  class="form-control">
							<font color="red"><?php echo form_error('email') ?></font>
					</div>	
						 <div class="form-group <?php if(form_error('password')) echo 'has-error'; ?>">
                        <label>Password
                            <span style="color:red">*</span>
                        </label>
                     
                            <input type="password" name="password" id="password" class="form-control" placeholder="Enter Password">
                            <font color="red"><?php echo form_error('password') ?></font>

                		</div>
            


                    <div class="form-group <?php if(form_error('passconf')) echo 'has-error'; ?>">
                        <label>Password Confirmation
                            <span style="color:red">*</span>
                        </label>
                 
                            <input type="password" name="passconf" id="passconf" class="form-control" placeholder="Enter Confirmation Password" onChange="checkPasswordMatch();">
                            <font color="red"><?php echo form_error('passconf') ?></font>

                  <div class="registrationFormAlert" id="divCheckPasswordMatch">
					</div>
                    </div>	

      				
						
					
					<div class="form-group <?php if(form_error('mob_no')) echo 'has-error'; ?>">
						<label>Mobile Number <span style="color:red">*</span></label>
						<input type="text" placeholder="Enter Mobile Number Here.."  name="mob_no" id="mob_no"  class="form-control">
							<font color="red"><?php echo form_error('mob_no') ?></font>
					</div>		
					
					<br>
				<button type="submit" name="submit" value="userRegistration" class="btn btn-primary btn-lg btn-block">
                        <i class="fa fa-edit"></i> Submit to Register
                    </button>			
					</div>
				</form> 
				</div>
	</div>
	</div>
</div></div>


<script>
	function checkPasswordMatch() {
    var password = $("#password").val();
    var confirmPassword = $("#passconf").val();

    if (password != confirmPassword)
        $("#divCheckPasswordMatch").html("Passwords do not match!");
    else
        $("#divCheckPasswordMatch").html("Passwords match.");
}

    $(document).ready(function () {
   $("#password, #passconf").keyup(checkPasswordMatch);
});
</script>
 
   
</body>
</html>