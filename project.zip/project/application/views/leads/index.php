<div class="container">
<h2 class="text-center"><?php echo $title; ?></h2>
<div class="row">
<div class="col-md-3">

<input class="form-control" id="myInput" type="text" placeholder="Search"><span class="glyphicon glyphicon-name"></span>
</div></div>
  <br>
<table class="table" border='1' cellpadding='4'>
<thead class="bg-danger text-white">
    <tr>
        <td><strong>Action</strong></td>
        <td><strong>Name</strong></td>
        <td><strong>Email</strong></td>
        <td><strong>Mobile No</strong></td>
        <td><strong>Address</strong></td>
        <td><strong>City</strong></td>
        <td><strong>Date</strong></td>
    </tr>
    </thead>
<?php foreach ($news as $news_item): ?>
<tbody id="myTable">
        <tr>
        <td>
        <a class="btn btn-primary btn-sm" href="<?php echo site_url('leads/new_view/'.$news_item['sno']); ?>" data-toggle="tooltip" title="View Details" style="width:30%;"><i class="fa fa-eye"></i> View </a>
        <a class="btn btn-success btn-sm" href="<?php echo site_url('leads/edit/'.$news_item['sno']); ?>" data-toggle="tooltip" title="Edit Details" style="width:30%;"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit </a>
        <a class="btn btn-danger btn-sm" href="<?php echo site_url('leads/delete/'.$news_item['sno']); ?>" onClick="return confirm('Are you sure you want to delete?')" data-toggle="tooltip" title="Delete" style="width:33%;"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete </a>
               
            </td>
            <td><?php echo $news_item['uname']; ?></td>
            <td><?php echo $news_item['email']; ?></td>
            <td><?php echo $news_item['phone_no']; ?></td>
            <td><?php echo $news_item['address']; ?></td>
            <td>
            <?php 
              $cities =  $this->db->get_where('city', array('id' => $news_item['city']));
                  if($cities->num_rows() > 0){
                    foreach($cities->result() as $city){
                      echo $city->name;
                    }
                  } ?>
            </td>
            <td><?php echo $news_item['date']; ?></td>
        </tr>
</tbody> 
<?php endforeach; ?>
</table>
</div>
<script>
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
</script>
