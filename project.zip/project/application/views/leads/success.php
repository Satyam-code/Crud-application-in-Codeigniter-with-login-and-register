<h2 class="text-center">Lead added successfully!</h2>
