<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<head>
  <!-- Modernizer for Portfolio -->
    <script src="<?php echo base_url();?>assets/js/modernizer.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
</head>
    <?php include("templates/header.php") ?>
  
  <style>
  .modal-header, h4, .close {
    background-color: #5cb85c;
    color:white !important;
    font-size: 30px;
  }
  .modal-footer {
    background-color: #f9f9f9;
  }
  </style>
</head>
<body>

<div class="container">
 
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="padding:35px 50px;text-align: center;">
          <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
          <h4 style="text-align:center;"><span class="glyphicon glyphicon-thumbs-up"></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thank You &nbsp; !</h4>
        </div>
        <div class="modal-body" style="padding:40px 50px;">
          
            <h3 style="text-align: center;color: blue;">We will get back to you soon..</br><i class="fa fa-smile-o fa-4x" style="color: yellow;" aria-hidden="true"></i></h3>
       
        
        </div>
   
      </div>
      </div>
    </div>
<!--   </div> 
</div> -->
 
<script>
$(document).ready(function(){
  
    $("#myModal").modal();
  
});
</script>


</body>
</html>
