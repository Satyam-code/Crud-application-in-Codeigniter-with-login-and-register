<?php
class Enquiry_list_Model extends CI_Model 
{ 
             public function getusers(){ 
				$query = $this->db->order_by('id', 'desc')->get('lead_details');
                         return $query->result();
    
    }
}