<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Register_model extends CI_Model {
 public function authonication(){

        $this->load->library('user_agent');

        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $password = sha1($password);

		$credential = "(email = '".$email."' AND password = '".$password."') OR (contactno = '".$email."' AND password = '".$password."') ";
        $query = $this->db->order_by('id','asc')->limit(1,0)->where($credential)->get('register');

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r);
			
			
			
            // if($r->active == 0)
            // {
            //     $this->session->set_flashdata('loggedIn_fail', 'Account is not active yet !');
            //     return false;
            // }elseif($r->active == 2){
            //     $this->session->set_flashdata('loggedIn_fail', 'Account Is Inactive !');
            //     return false;
            // }elseif($r->active == 3){
            //     $this->session->set_flashdata('loggedIn_fail', 'Account Is Blocked By Admin !');
            //     return false;
            // }

            /**
             * data for store in session
             */

            $user_data = [
                'email' => $email,
                'user_id' => $r->id,
             
                'logged_in' => true,
            ];

            // set user status = online
            $login_update = [
                'online_status' => 1,
                //'user_lastlogin' => time()
            ];
            $this->db->where('id', $r->id)->update('register', $login_update);

            //store login info in session
            $this->session->set_userdata('logged_user', $user_data);

            // insert user agent and ip into log
            // $user_agent = $this->agent->agent_string();

            // $user_device_info = [
            //     'user_id' => $r->id,
            //     'ip' => $_SERVER['REMOTE_ADDR'],
            //     'device_info' => $user_agent,
            //     'created_at' => time()
            // ];

            // $this->db->insert('log', $user_device_info);

            return true;
        } else {
            $this->session->set_flashdata('loggedIn_fail', 'Wrong email or password !');
            return false;
        }
    }

    public function register(){

        $this->load->helper('string'); //load string helper
        
       
        $row_password   = $this->input->post('password');
        $password       = sha1($row_password);
       $my_image = '';

        if($this->input->post('my_count') > 1){
            $number_of_files = count($_FILES['multipleFiles']['name']);
            $files = $_FILES;
            if(!is_dir('uploads')){
                mkdir('.!/uploads',0777,true);
            }
            for($i=0;$i < $number_of_files;$i++){
                $_FILES['multipleFiles']['name']        = $files['multipleFiles']['name'][$i];
                $_FILES['multipleFiles']['type']        = $files['multipleFiles']['type'][$i];
                $_FILES['multipleFiles']['tmp_name']    = $files['multipleFiles']['tmp_name'][$i];
                $_FILES['multipleFiles']['error']       = $files['multipleFiles']['error'][$i];
                $_FILES['multipleFiles']['size']        = $files['multipleFiles']['size'][$i];

                $uploadPath = 'uploads'; //path of image//

                $config['upload_path']      = $uploadPath;
                $config['allowed_types']    = 'gif|jpg|png|jpeg';
                //$this->upload->initialize($config);
                $this->load->library('upload', $config);

                if($this->upload->do_upload('multipleFiles')){
                    $fileData = $this->upload->data();
                    $uploadData[$i]['file_name'] = $fileData['file_name'];
                    $my_image = $fileData['file_name'];
                }
            }
        }
        
        $now = date('Y-m-d H:i:s');
    
    
        
        //set all data for inserting into database
        $data = [
           
            'first_name'        => ucfirst ($this->input->post('first_name')),
            'last_name'         => ucfirst ($this->input->post('last_name')),
            'password'          => $password,
            'row_pass'          => $row_password,
            'email'             => $this->input->post('email'),
            'contactno'         => $this->input->post('mob_no'),
           // 'gst_no'            => $this->input->post('gst_no'),
           // 'company_name'      => $this->input->post('firm_name'),
            //'street_address'    => $this->input->post('firm_add'),
          
            //'gst_registration'  => $this->input->post('gst_reg'),
         
            //'city'              => $this->input->post('city'),
            //'state'             => $this->input->post('state'),
            //'postal_code'       => $this->input->post('pincode'),
            //'return_type'       => $this->input->post('return_type'),
            //'active'            => 1,
            //'photo'             => $my_image,
            //'created_by'        => '01', //Auto Register
            'created_at'        => $now,
            //'modified_at'       => time()
        ];
        
      $email = $this->input->post('email');
        $contactno  = $this->input->post('contactno');
        
        $query  = $this->db->insert('register', $data);
        
           $adminEmail = 'satyamyadav@afitech.org';

            $subject = 'Jp Advocate';
            $this->load->library('email');
            $this->email->set_mailtype("html");
            $this->email->from($adminEmail);
            $this->email->to($email);
            $this->email->cc($adminEmail);
            $this->email->subject($subject);
            $message = 'You are successfully Registered.';
            $this->email->message($message);
            $this->email->send();
        if($query){
            return true;
                }else{
                    return false;
                }
            }
            

        


}